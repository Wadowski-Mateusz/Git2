//
// Created by mateu on 17.10.2021.
//

#ifndef SIMPLECALC_CALC_H
#define SIMPLECALC_CALC_H

#include <stdio.h>

class Calc{
public:
    int add (int, int);
    int subtract(int, int);
    double volume (int, int, int, int);
    void help();
};

#endif //SIMPLECALC_CALC_H
